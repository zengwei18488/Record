#!/bin/bash
# =================================================================
# Target: Debian 12 (Bookworm) on RK3568
# Compliance: IEC 62443-4-2 (Identification & Authentication)
# Description: Hardening Password Policy, Account Lockout, and Auditing
# =================================================================

# Ensure the script is run as root
if [[ $EUID -ne 0 ]]; then
   echo "Error: This script must be run as root/sudo."
   exit 1
fi

# Define a robust install function with retries
smart_install() {
    local MAX_RETRIES=5
    local COUNT=0
    local SUCCESS=1

    while [ $COUNT -lt $MAX_RETRIES ]; do
        echo "Attempting to install: $@ (Attempt $((COUNT+1))/$MAX_RETRIES)"
        
        # 使用 -y 自动确认，并设置超时参数
        apt-get install -y -o DPkg::Lock::Timeout=60 "$@"
        
        if [ $? -eq 0 ]; then
            echo "Installation of $@ successful!"
            SUCCESS=0
            break
        else
            COUNT=$((COUNT+1))
            echo "Installation failed. Waiting 5 seconds before retrying..."
            sleep 5
            # 如果是锁被占用，尝试清理（可选）
            apt-get update --fix-missing
        fi
    done

    if [ $SUCCESS -ne 0 ]; then
        echo "Error: Failed to install $@ after $MAX_RETRIES attempts. Please check your network."
        exit 1
    fi
}

echo "Starting IEC 62443 Hardening for Debian 12..."

# 1. Install Necessary Modules
# libpam-pwquality: For password strength
# rsyslog: For security auditing logs
echo "[1/5] Updating package lists..."
apt-get update || echo "Update warning: some sources failed."

echo "[1/5] Installing security modules with retry logic..."
smart_install libpam-pwquality rsyslog cracklib-runtime wamerican libpam-cap whois
update-cracklib

# 2. Configure Password Complexity (Min 12 chars, 4 classes)
echo "[2/5] Configuring Password Complexity Policy..."
CONF_PW="/etc/security/pwquality.conf"

# --- 修复部分：如果文件不存在则创建它 ---
if [ ! -f "$CONF_PW" ]; then
    echo "Creating missing pwquality.conf..."
    mkdir -p /etc/security
    touch "$CONF_PW"
fi

# 使用 tee 直接写入配置，这样比 sed 更可靠，且不受原文件是否存在影响
cat <<EOF > $CONF_PW
# Configuration for libpam-pwquality module
# Compliance: IEC 62443-4-2
minlen = 12
minclass = 4
retry = 3
dcredit = -1
ucredit = -1
lcredit = -1
ocredit = -1
dictcheck = 0
EOF

# 3. Configure Account Lockout (FAILLOCK)
# 5 failed attempts = 30 mins lockout
echo "[3/5] Configuring Account Lockout (5 attempts / 30 mins)..."
AUTH_PAM="/etc/pam.d/common-auth"

# Backup original
cp $AUTH_PAM ${AUTH_PAM}.bak

# Clean up any previous faillock lines to avoid duplicates
sed -i '/pam_faillock.so/d' $AUTH_PAM

# Correct PAM sequence for Debian 12:
# We use 'tee' to ensure the order is correct: preauth -> unix -> authfail -> authsucc
cat <<EOF > $AUTH_PAM
auth    required                    pam_env.so
auth    required                    pam_faillock.so preauth silent audit deny=5 unlock_time=1800
auth    [success=1 default=ignore]  pam_unix.so nullok
auth    [default=die]               pam_faillock.so authfail audit deny=5 unlock_time=1800
auth    sufficient                  pam_faillock.so authsucc audit deny=5 unlock_time=1800
auth    required                    pam_deny.so
auth    required                    pam_permit.so
auth    optional                    pam_cap.so
EOF

# 4. Clean up faulty modules (Fix for LXDM/GUI login loop)
echo "[4/5] Cleaning up legacy/missing PAM modules..."
# Disable gnome-keyring if it's causing login loop
if [ -f /etc/pam.d/lxdm ]; then
    sed -i 's/.*pam_gnome_keyring.so.*/#&/g' /etc/pam.d/lxdm
fi

# 5. Enable Security Auditing
echo "[5/5] Enabling Security Auditing Logs..."
systemctl enable --now rsyslog
sleep 1
echo "auth,authpriv.*    /var/log/auth.log" > /etc/rsyslog.d/audit.conf
systemctl restart rsyslog
sleep 1
# --- 修复 faillock 目录缺失问题 ---
echo "Ensuring faillock directory exists..."
if [ ! -d "/var/run/faillock" ]; then
    mkdir -p /var/run/faillock
    chmod 755 /var/run/faillock
fi

# 确保在配置文件中指明目录位置
if [ -f "/etc/security/faillock.conf" ]; then
    sed -i 's|^#\? \?dir =.*|dir = /var/run/faillock|' /etc/security/faillock.conf
fi

# Reset any accidental lockouts during setup
faillock --reset

echo "================================================================="
echo "SUCCESS: Debian 12 Hardening Complete."
echo "SYSTEM POLICY:"
echo "- Minimum Password Length: 12"
echo "- Character Classes Required: 4 (Upper, Lower, Digit, Special)"
echo "- Account Lockout: 5 attempts / 30 minutes"
echo "- Security Logs: /var/log/auth.log"
echo "================================================================="
echo "IMPORTANT: Please set a strong password now: 'passwd linaro'"
