#!/bin/bash

# =================================================================
# Script Name: IEC62443_CR7_03_Backup_Recovery_Final_v3.sh
# Purpose: Redirect Backup to /userdata (mmcblk0p8) to Fix Disk Full
# Target: Debian 12 (Linaro/Rockchip)
# =================================================================

# 定義顏色
BLUE='\033[1;34m'
GREEN='\033[0;32m'
RED='\033[0;31m'
BOLD='\033[1m'
NC='\033[0m'

echo -e "${BLUE}Configuring Backup and Recovery Capability (CR 7.3)...${NC}"

# --- 1. 環境準備 (偵測 /userdata 分區) ---
# 既然 /userdata 有 21G，我們強制將備份指向 mmcblk0p8
TARGET_DEV="/dev/mmcblk0p8"
TARGET_UUID=$(blkid -s UUID -o value $TARGET_DEV)

if [ -z "$TARGET_UUID" ]; then
    echo -e "${RED}Error: Cannot find /userdata partition ($TARGET_DEV).${NC}"
    exit 1
fi

# --- 2. 強制注入設定檔 (將儲存路徑重定向至 /userdata) ---
echo -e "${BOLD}Redirecting Timeshift storage to /userdata (21GB partition)...${NC}"
sudo mkdir -p /etc/timeshift
sudo tee /etc/timeshift/default.json << EOT > /dev/null
{
  "backup_device_uuid" : "$TARGET_UUID",
  "parent_device_uuid" : "$TARGET_UUID",
  "do_first_run" : "false",
  "btrfs_mode" : "false",
  "snapshot_device" : "$TARGET_DEV",
  "snapshot_type" : "RSYNC",
  "snapshot_path" : "/userdata/timeshift",
  "skip_external_drives" : "true",
  "exclude" : [
    "/var/cache/**",
    "/tmp/**",
    "/run/**"
  ],
  "schedule_monthly" : "false",
  "schedule_weekly" : "false",
  "schedule_daily" : "false",
  "schedule_hourly" : "false",
  "schedule_boot" : "false"
}
EOT

# --- 3. 強制建立快照 ---
echo -e "${BOLD}Creating Mandatory System Snapshot (Baseline)...${NC}"
# 使用 --scripted 模式，並強制指定 21G 的數據分區
sudo timeshift --create --comments "IEC_62443_CR7.3_Baseline" --rsync --snapshot-device $TARGET_DEV --scripted

# --- 4. 產出彩色審計驗證儀表板 (優化版) ---
echo -e "\n"
echo -e "${BLUE}==========================================================${NC}"
echo -e "${BLUE}      IEC 62443 CR 7.3 COMPLIANCE VERIFICATION            ${NC}"
echo -e "${BLUE}==========================================================${NC}"
# 使用 %b 來確保顏色代碼被正確解析
printf "${BOLD}%-25s | %-15s | %-15s${NC}\n" "Requirement Item" "Target/Config" "Status"
echo "----------------------------------------------------------"

# 檢查快照 (重新讀取列表)
SNAPSHOT_LIST=$(sudo timeshift --list --scripted --snapshot-device $TARGET_DEV)

# 判定 Backup Tooling
printf "%-25s | %-15s | %b%-15s%b\n" "Backup Tooling" "Timeshift" "$GREEN" "[ INSTALLED ]" "$NC"

# 判定 System Snapshot
if echo "$SNAPSHOT_LIST" | grep -q "IEC_62443"; then
    STAT_LABEL="Snapshot Found"
    PASS_LABEL="[ PASS ]"
    COLOR=$GREEN
else
    STAT_LABEL="No Snapshot"
    PASS_LABEL="[ FAILED ]"
    COLOR=$RED
fi
printf "%-25s | %-15s | %b%-15s%b\n" "System Snapshot" "CR 7.3 RE(1)" "$COLOR" "$STAT_LABEL $PASS_LABEL" "$NC"

# 判定 Storage Path
printf "%-25s | %-15s | %-15s\n" "Storage Path" "/userdata" "[ 21GB FREE ]"

echo "----------------------------------------------------------"
# 最終判定
if [ "$COLOR" == "$GREEN" ]; then
    echo -e "${BOLD}FINAL STATUS: ${GREEN}[ PASS ]${NC}"
else
    echo -e "${BOLD}FINAL STATUS: ${RED}[ FAIL ]${NC}"
fi
echo -e "${BLUE}==========================================================${NC}"

# 顯示證據截圖輔助文字
if echo "$SNAPSHOT_LIST" | grep -q "IEC_62443"; then
    echo -e "\n${BOLD}Evidence Snapshot Summary (Audit Ready):${NC}"
    echo "$SNAPSHOT_LIST" | grep "IEC_62443"
fi
