/*
 * SPDX-License-Identifier:     GPL-2.0+
 *
 * Copyright (c) 2020 Rockchip Electronics Co., Ltd
 */

#ifndef __CONFIGS_RK3568_AFEE630_H
#define __CONFIGS_RK3568_AFEE630_H

#include <configs/evb_rk3568.h>


#define GPIO_WDT_MSP430_PING 144
#define WDT_MSP430_I2C_NUM 3

#define STD_SARADC_HW_ID_CHANNEL 1

#undef CONFIG_CONSOLE_DISABLE_CLI

#endif /*__CONFIGS_RK3568_AFEE630_H*/
