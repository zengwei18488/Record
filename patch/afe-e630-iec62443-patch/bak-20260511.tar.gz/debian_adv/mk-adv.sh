#!/bin/bash -e
TARGET_ROOTFS_DIR="../debian/binary"
X11_COMMON_FILE="/etc/X11/Xresources/x11-common"

echo "in mk-adv.sh"

echo "BUILD_IN_CHINA : $BUILD_IN_CHINA"

#---------------Overlay--------------
echo "1.copy overlay"
pwd
sudo cp  $TARGET_ROOTFS_DIR/etc/xdg/xfce4/xfconf/xfce-perchannel-xml/xfce4-power-manager.xml \
		 $TARGET_ROOTFS_DIR/etc/xdg/xfce4/xfconf/xfce-perchannel-xml/xfce4-power-manager.xml.enable

sudo cp  $TARGET_ROOTFS_DIR/usr/bin/power-key.sh \
		 $TARGET_ROOTFS_DIR/usr/bin/power-key.sh.enable

sudo cp -rf overlay-adv/* $TARGET_ROOTFS_DIR/

# packages folder
sudo mkdir -p $TARGET_ROOTFS_DIR/packages
sudo cp -rf packages-adv/$ARCH/* $TARGET_ROOTFS_DIR/packages/

# npu include
sudo mkdir -p $TARGET_ROOTFS_DIR/packages
sudo cp -rf ../external/rknpu2/runtime/Linux/librknn_api/include/* $TARGET_ROOTFS_DIR/usr/include/

# firmware
sudo cp  $TARGET_ROOTFS_DIR/system/etc/firmware/nvram_ap6275p.txt \
		 $TARGET_ROOTFS_DIR/system/etc/firmware/nvram_AP6275P.txt

# kernel ko
sudo find ../kernel/drivers/net/wireless/rockchip_wlan/*  -name "*.ko" | \
    xargs -n1 -i sudo cp {} $TARGET_ROOTFS_DIR/lib/modules/

sudo find ../kernel/drivers/bluetooth/*  -name "*.ko" | \
    xargs -n1 -i sudo cp {} $TARGET_ROOTFS_DIR/lib/modules/

sudo find ../kernel/drivers/hailort-drivers/*  -name "*.ko" | \
    xargs -n1 -i sudo cp {} $TARGET_ROOTFS_DIR/lib/modules/

sudo find ../kernel/drivers/net/ethernet/*  -name "*.ko" | \
    xargs -n1 -i sudo cp {} $TARGET_ROOTFS_DIR/lib/modules/

sudo find ../kernel/drivers/bus/mhi/*  -name "*.ko" | \
    xargs -n1 -i sudo cp {} $TARGET_ROOTFS_DIR/lib/modules/

sudo cp ../kernel/scripts/bmpconvert $TARGET_ROOTFS_DIR/usr/local/bin/

#if [ "$BUILD_IN_CHINA" == "TRUE" ]; then
#	sudo cp $TARGET_ROOTFS_DIR/etc/apt/sources.list.cn $TARGET_ROOTFS_DIR/etc/apt/sources.list
#fi

echo "2.install/remove/adjust debian"

#finish() {
#	sudo umount $TARGET_ROOTFS_DIR/dev
#	exit -1
#}
#trap finish ERR

#sudo mount -o bind /dev $TARGET_ROOTFS_DIR/dev
cat <<EOF | sudo chroot $TARGET_ROOTFS_DIR

if [ "$BUILD_IN_CHINA" == "TRUE" ]; then
	cp /etc/apt/sources.list.cn /etc/apt/sources.list
fi

#---------------Remove--------------

#---------------Install--------------
mkdir -p /var/cache/apt/archives/partial

apt-get update
# install RK
chmod 0644  /lib/systemd/system/rkaiq_3A.service
mv /usr/bin/rkaiq_3A_server_back /usr/bin/rkaiq_3A_server

export DEBIAN_FRONTEND=noninteractive
export APT_LISTCHANGES_FRONTEND=none

apt-get install -y gnome-screenshot
apt-get install -y mtd-utils
apt-get install -y i2c-tools
apt-get install -y minicom
apt-get install -y ethtool
echo 'iperf3 iperf3/start_daemon boolean false' | debconf-set-selections
apt-get install -y iperf3
apt-get install -y pciutils
apt-get install -y hdparm fio
apt-get install -y ftp
apt-get install -y exfat-fuse exfatprogs
apt-get install -y xfsprogs
apt-get install -y dosfstools
apt-get install -y nvme-cli
apt-get install -y wmctrl
#for rpmb
apt-get install -y mmc-utils
#for can
apt-get install -y can-utils
#for 4G
apt-get install -y libpcap0.8 ppp
apt-get install -y usb-modeswitch mobile-broadband-provider-info modemmanager

#for bt udev
apt-get install -y at
apt-get install -y bluez-hcidump
apt-get install -y bluez-alsa-utils

# for mosquitto
apt-get install -y mosquitto mosquitto-dev libmosquitto-dev

# for modbus
apt-get install -y libmodbus-dev

# for tftp
apt-get install -y tftp

# for sqlite
apt-get install -y sqlite3

# for openvpn
apt-get install -y openvpn

# for vnc
apt-get install -y x11vnc

# for opc ua
# apt-get install -y python3-opcua python-opcua-tools

#for sync time
apt-get install -y cron
# mv /etc/crontab.back /etc/crontab

#for Chinese fonts
apt-get install -y xfonts-intl-chinese xfonts-wqy fonts-wqy-microhei fonts-wqy-zenhei fonts-aenigma

# config Xterm font
echo "" >> $X11_COMMON_FILE
echo "! English font" >> $X11_COMMON_FILE
echo "xterm*faceName: DejaVu Sans Mono:antialias=True:pixelsize=13" >> $X11_COMMON_FILE
echo "" >> $X11_COMMON_FILE
echo "! Chinese font" >> $X11_COMMON_FILE
echo "xterm*faceNameDoublesize: WenQuanYi Zen Hei Mono:antialias=True:pixelsize=13" >> $X11_COMMON_FILE
echo "Xcursor.size: 16" >> $X11_COMMON_FILE

# HACK debian11.3 to fix bug
apt-get install -y fontconfig --reinstall

# For logrotate limit log size
apt-get install -y logrotate
# mv /etc/cron.daily/logrotate.back /etc/cron.daily/logrotate

#for docker
dpkg -i  /packages/docker/*.deb
apt-get install -f -y

# qt
apt-get install -y gdbserver
apt-get install -y libqt5webenginecore5
apt-get install -y libqt5quickwidgets5
apt-get install -y libqt5webenginewidgets5
apt-get install -y libqt5*-dev
apt-get install -y qt5*-dev
apt-get install -y qt*5-dev
apt-get install -y qt*5-private-dev
apt-get install -y qt*5-doc-dev
apt-get install -y qt5-qmake

# build
apt-get install -y build-essential

# xinput
apt-get install -y xinput xinput-calibrator

# PowerSuite
apt-get install -y imagemagick libwebkit2gtk-4.0-37

# EdgeAI
apt-get install -y sysstat libqrencode-dev libqt5charts5 libqt5charts5-dev

# RT Test
apt-get install -y rt-tests

# onboard
apt-get install -y onboard
# mv /Onboard.desktop /home/linaro/Desktop/
# chown linaro:linaro /home/linaro/Desktop/Onboard.desktop

# lxdm
apt-get install -y lxdm
# sed -i "s/# autologin=.*/autologin=linaro/" /etc/lxdm/lxdm.conf
sed -i "s~\(^# session=.*\)~\session=/usr/bin/startxfce4~" /etc/lxdm/lxdm.conf

######  iec62443
apt-get install -y ima-evm-utils attr keyutils
apt-get install -y libpam-pwquality rsyslog cracklib-runtime wamerican libpam-cap whois
apt-get install -y sysstat libpam-modules usbguard logrotate
apt-get install -y xscreensaver xscreensaver-data-extra dbus-x11
apt-get remove --purge ntp systemd-timesyncd -y
apt-get install -y chrony
apt-get install -y bc
apt-get install -y clamav clamav-daemon
apt-get install -y unattended-upgrades
apt-get install -y systemd-coredump
apt-get install -y rng-tools-debian
apt-get install -y secure-delete memtester extundelete
apt-get install -y iptables dnsutils
apt-get install -y ufw
apt-get install -y auditd libaudit1 libauparse0 fail2ban python3-pyinotify python3-systemd
systemctl enable rng-tools-debian
update-cracklib

# hailo
# tar xvf /packages/hailo/hailort_*.tar.gz -C /

#---------------Adjust--------------
systemctl enable advinit.service
systemctl enable adv_bootprocess.service
systemctl enable adv-boot-times.service
systemctl enable adv-uio.service
systemctl enable adv-hailo.service
# systemctl enable adv-sync-rtc-time.timer
systemctl enable adv-cellular-daemon.service
systemctl enable adv-wifibt-init.service
systemctl enable adv-pcie-lan.service
systemctl enable adv-sd-boot.service
systemctl enable adv-codec.service
systemctl enable adv-suspend.service

systemctl disable wifibt-init.service
mkdir -p /system/lib/
ln -sf /lib/modules /system/lib/modules

systemctl disable nvmf-autoconnect.service

#for login
echo "linaro:Init@2026#user" | chpasswd
echo "root:Init@2026#super" | chpasswd

#locale
sed -i 's/# en_US.UTF-8 UTF-8/en_US.UTF-8 UTF-8/g' /etc/locale.gen
sed -i 's/# zh_CN GB2312/zh_CN GB2312/g' /etc/locale.gen
sed -i 's/# zh_CN.GB18030 GB18030/zh_CN.GB18030 GB18030/g' /etc/locale.gen
sed -i 's/# zh_CN.GBK GBK/zh_CN.GBK GBK/g' /etc/locale.gen
sed -i 's/# zh_CN.UTF-8 UTF-8/zh_CN.UTF-8 UTF-8/g' /etc/locale.gen
sed -i 's/# zh_TW BIG5/zh_TW BIG5/g' /etc/locale.gen
sed -i 's/# zh_TW.EUC-TW EUC-TW/zh_TW.EUC-TW EUC-TW/g' /etc/locale.gen
sed -i 's/# zh_TW.UTF-8 UTF-8/zh_TW.UTF-8 UTF-8/g' /etc/locale.gen
locale-gen

#audio
sudo sed -i '/use-original-prio/s/true/false/' /usr/share/wireplumber/main.lua.d/40-device-defaults.lua

#timezone
#ln -sf /usr/share/zoneinfo/Asia/Shanghai /etc/localtime
#echo "Asia/Shanghai" >/etc/timezone

# network
rm /etc/resolv.conf
cd /etc/resolvconf/
ln -sf /run/resolvconf/resolv.conf
cd /etc/
ln -sf resolvconf/resolv.conf resolv.conf

# python
cd /usr/bin/
ln -sf python3 python

# ssh
# sed -i "s/^#PermitRootLogin.*/PermitRootLogin yes/" /etc/ssh/sshd_config

# for docker
update-alternatives --set iptables /usr/sbin/iptables-legacy
update-alternatives --set ip6tables /usr/sbin/ip6tables-legacy


if [ "$BUILD_IN_CHINA" == "TRUE" ]; then
	cp /etc/apt/sources.list.back /etc/apt/sources.list
fi

#---------------Clean--------------
apt-get clean
apt-get autoclean
apt autoremove -y

rm -rf /src/
rm -rf /usr/share/icons/Tango/
rm -rf /var/lib/apt/lists/*
rm -rf /var/cache/
rm -rf /packages/

mv /rockchip-test/ /tools/test/rockchip
find /tools/test/rockchip -name "*.sh" -exec sed -i 's|/rockchip-test/|/tools/test/rockchip/|g' '{}' \;

cat <<'_SECURE_TTY_' > /etc/securetty
console
ttyFIQ0
ttyS2
ttyS0
_SECURE_TTY_

chmod 600 /etc/securetty

mkdir -p /etc/ima
cat <<POLICY > /etc/ima/ima-policy
# Measure everything
measure func=BPRM_CHECK mask=MAY_EXEC
# Appraise (Enforce) all executables
appraise func=BPRM_CHECK mask=MAY_EXEC
appraise func=MODULE_CHECK
POLICY

sed -i '/[[:space:]]\/[[:space:]]/ s/defaults/defaults,i_version/' /etc/fstab

find /etc /lib /sbin /bin /usr -type f -exec evmctl ima_hash -a sha256 {} \;

history -c
echo "" > /root/.bash_history

EOF

# sudo umount $TARGET_ROOTFS_DIR/dev


